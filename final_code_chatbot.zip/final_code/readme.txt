Download the movie dataset corpus: https://www.cs.cornell.edu/~cristian/Cornell_Movie-Dialogs_Corpus.html 

Unzip the archived folder.

Use converter.py to create the train and test data sets from the movie_lines.txt file in the unzipped folder.

Rename files �train.a� and �train.b� to �train.en� and �train.fr� since the translation script assumes it translates from english to french.

Use clean_data.py to remove unwanted tags from the train files.

Install a virtual environment.

Activate the virtual environment and install tensorflow 0.12.0 and all its required dependencies.

Open a tmux session

Run the translate.py script (Path: tensorflow/tensorflow/tree/r0.12/tensorflow/models/rnn/translate)